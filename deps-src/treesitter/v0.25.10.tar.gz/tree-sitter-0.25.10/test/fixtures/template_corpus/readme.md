The Template Corpus
===================

This directory contains corpus tests that exercise parsing a set of disjoint ranges within a file.

Each of these input files contains source code surrounded by the delimiters `<%` and `%>`. The content outside of these delimiters is meant to be ignored.