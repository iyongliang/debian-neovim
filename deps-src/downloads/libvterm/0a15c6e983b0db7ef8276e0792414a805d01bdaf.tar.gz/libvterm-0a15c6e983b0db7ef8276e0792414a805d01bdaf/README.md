# libvterm fork

This is a fork of https://www.leonerd.org.uk/code/libvterm. An exact mirror
of upstream is in the branch `mirror`.
