"C grammar for tree-sitter"

from ._binding import language
