
# tree-sitter-vim

[![CI][ci]](https://github.com/tree-sitter-grammars/tree-sitter-vim/actions/workflows/ci.yaml)
[![discord][discord]](https://discord.gg/w7nTvsVJhm)
[![matrix][matrix]](https://matrix.to/#/#tree-sitter-chat:matrix.org)

A tree-sitter parser for Vimscript files.

## References

* [Write a Vim script](https://neovim.io/doc/user/usr_41.html)

[ci]: https://img.shields.io/github/actions/workflow/status/tree-sitter-grammars/tree-sitter-vim/main.yml?logo=github&label=CI
[discord]: https://img.shields.io/discord/1063097320771698699?logo=discord&label=discord
[matrix]: https://img.shields.io/matrix/tree-sitter-chat%3Amatrix.org?logo=matrix&label=matrix
